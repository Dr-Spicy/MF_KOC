Here are some info on the non self-explaning fields.

creators:
- last_modify_ts: the sraped moment of KOC's profile page in 13-bit Unix time stamp

contents:
- video_url: only avaiable for video typed notes(but we don't plan to analysze videos)
- time: the moment this note has been posted by KOC in 13-bit Unix time stamp
- last_update_time: the moment this note has been updated(via interaction from other users or modification by KOC) in 13-bit Unix time stamp
- last_modify_ts: the sraped moment of this note in 13-bit Unix time stamp